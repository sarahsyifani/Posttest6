package posttest6;

public interface coba {
    public void pembukaangrup(String greetgrup);
    public void pembukaansoldu(String greetsoldu);
}
